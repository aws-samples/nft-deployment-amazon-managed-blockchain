const ethers = require('ethers');
const fs = require('fs/promises');

const generateRandomString = (length=6)=>Math.random().toString(20).substr(2, length)

const createEthereumWallet = async () => {
  //use user provided entropy or create our own
  let entropy = process.argv[2] || generateRandomString(16);
  console.log(`User provided entropy: ${entropy.toString()}`)
  
  //create wallet with both system-level entropy and app-based entropy
  let newWallet = ethers.Wallet.createRandom(entropy);

  //bundle wallet details into structured format for writing to file
  let writableWallet = {
    address: newWallet.address,
    publicKey: newWallet.publicKey,
    privateKey: newWallet.privateKey,
    mnemonic: newWallet.mnemonic
  }

  //create filename based on date of creation
  let date = Date.now();
  let filePath = `${__dirname}/eth_wallet_${date}.json`
  //write the wallet as a JSON file in package dir
  await fs.writeFile(filePath, JSON.stringify(writableWallet));

  console.log(`DONE: Created your wallet at ${filePath}`)

}

createEthereumWallet()

