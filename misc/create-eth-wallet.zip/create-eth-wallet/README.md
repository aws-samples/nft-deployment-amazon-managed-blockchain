## How to use this utility
This tool can be used to create a valid Ethereum wallet, complete with a private key and mnemonic. The wallet is stored in a .json file stored locally in this package directory, which means that this does *NOT* provide airgapped security for your private keys/mnemonics. As a general rule of thumb, avoid using this method of wallet generation for production except in airgapped environments - funds could be at risk if care is not taken during this process.

1. *User-provided entropy*: this utility allows the user to provide their own string-based entropy as arguments to    augment the existing entropy sources included in wallet generation. This gives users more confidence that their wallet is being produced with adequate entropy.
  
  ./createEthereumWallet.sh <string entropy>

2. *Without additional entropy*: this utility also allows the user to simply create a new wallet without any additional entropy 
  
  ./createEthereumWallet.sh 


## Troubleshooting 

1. If you get an error when running the bash script stating *"Permission denied."*, you must first run command: <chmod 755 createEthereumWallet.sh> to make the file executable on your system.

