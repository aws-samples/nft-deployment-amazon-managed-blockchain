#!/bin/sh

echo “Generating Ethereum wallet”
echo "WARNING: Creating a wallet on a hot, internet-connected device introduces increased risk of private key exposure!"
echo "Do not use this script in production except in instances where airgapped environments are used."
ENTROPY="$1"
node index.js $ENTROPY